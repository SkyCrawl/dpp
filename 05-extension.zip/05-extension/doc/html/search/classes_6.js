var searchData=
[
  ['otheritem',['OtherItem',['../class_configuration_1_1_base_1_1_other_item.html',1,'Configuration::Base']]]
];
