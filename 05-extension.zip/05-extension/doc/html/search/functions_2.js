var searchData=
[
  ['dispose',['Dispose',['../class_configuration_1_1_ini_file_1_1_file_i_o_config.html#ae323257e3b489b9aae971b7356a9d815',1,'Configuration::IniFile::FileIOConfig']]]
];
