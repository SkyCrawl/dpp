var searchData=
[
  ['save',['Save',['../interface_configuration_1_1_i_i_o_config.html#ae78e5a84d84447e29df9ed31c4a2f567',1,'Configuration.IIOConfig.Save()'],['../interface_configuration_1_1_i_i_o_config_definition.html#a7d32e979536db855be8290bf4e708bfc',1,'Configuration.IIOConfigDefinition.Save()'],['../class_configuration_1_1_ini_file_1_1_file_i_o_config.html#ad47d406720d5538fd093ad4e6e987d3e',1,'Configuration.IniFile.FileIOConfig.Save()']]],
  ['section',['Section',['../class_configuration_1_1_base_1_1_section.html',1,'Configuration::Base']]],
  ['section',['Section',['../namespace_configuration.html#af4a044a3c9f1e33b7aaac92c9989c981ad2c24d59e0baff4d0155fbdf62590867',1,'Configuration']]],
  ['sectiondefinition',['SectionDefinition',['../class_configuration_1_1_base_1_1_section_definition.html',1,'Configuration::Base']]],
  ['sections',['Sections',['../interface_configuration_1_1_i_config.html#ad5d7c10d3882760d49d1d53e72241209',1,'Configuration::IConfig']]],
  ['setcomment',['SetComment',['../class_configuration_1_1_base_1_1_section.html#aec255158b068a816033126d4698040b8',1,'Configuration.Base.Section.SetComment()'],['../class_configuration_1_1_base_1_1_value_item.html#aa27dc0537d5d855c115bccaa452c626a',1,'Configuration.Base.ValueItem.SetComment()'],['../interface_configuration_1_1_i_section.html#aaaf03ffbfec92c7c850290ec836948dd',1,'Configuration.ISection.SetComment()'],['../interface_configuration_1_1_i_value_item.html#ad8c8c68ccb58c3ef3990ea0764b9b606',1,'Configuration.IValueItem.SetComment()']]],
  ['stringvaluedefinition',['StringValueDefinition',['../class_configuration_1_1_base_1_1_string_value_definition.html',1,'Configuration::Base']]],
  ['stringvalueitem',['StringValueItem',['../class_configuration_1_1_base_1_1_string_value_item.html',1,'Configuration::Base']]]
];
