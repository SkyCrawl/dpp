var searchData=
[
  ['comment',['Comment',['../interface_configuration_1_1_i_config.html#a4fa9dc5313bd6d71bdd04c68100a4138',1,'Configuration.IConfig.Comment()'],['../interface_configuration_1_1_i_section.html#ab59a1a91fc6e18ddf9c08ef80a79aed6',1,'Configuration.ISection.Comment()'],['../interface_configuration_1_1_i_value_item.html#a15e1cdccf622a31ac9fcde20aba997f0',1,'Configuration.IValueItem.Comment()']]]
];
