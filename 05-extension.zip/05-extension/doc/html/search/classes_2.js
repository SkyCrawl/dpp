var searchData=
[
  ['doublevaluedefinition',['DoubleValueDefinition',['../class_configuration_1_1_base_1_1_double_value_definition.html',1,'Configuration::Base']]],
  ['doublevalueitem',['DoubleValueItem',['../class_configuration_1_1_base_1_1_double_value_item.html',1,'Configuration::Base']]]
];
